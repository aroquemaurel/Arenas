var searchData=
[
  ['mascotte',['Mascotte',['../classindividu_1_1combattant_1_1_mascotte.html',1,'individu::combattant']]]
];
