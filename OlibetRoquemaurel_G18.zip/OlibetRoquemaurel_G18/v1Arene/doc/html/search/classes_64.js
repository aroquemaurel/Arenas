var searchData=
[
  ['duelbasic',['DuelBasic',['../classinteraction_1_1_duel_basic.html',1,'interaction']]]
];
