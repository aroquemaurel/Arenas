var searchData=
[
  ['interaction',['interaction',['../classserveur_1_1_arene.html#ae8331f4b3d827f4c93d4b1c08a0d9399',1,'serveur.Arene.interaction()'],['../interfaceserveur_1_1_i_arene.html#aec66c3ded2467e80685b8cb4cf856cbc',1,'serveur.IArene.interaction()']]]
];
